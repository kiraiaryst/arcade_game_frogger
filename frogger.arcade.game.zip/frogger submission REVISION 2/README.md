# LOADING THE GAME
Start by opening the **index.html** file in your browser.

# HOW TO PLAY
+ To start the game, use _'left'_, _'up'_, _'right'_ and _'down'_ keys.
+ With the arrow keys you can move the player from the bottom of the field (grass), to the top (water).
+ Avoid colliding with the bugs or you lose.
+ To win, reach the top of the field (water).
+ When you hit the water, the game is won, and player is reset to initial position.

# LICENCE
Inspired by classic [Frogger](https://en.wikipedia.org/wiki/Frogger) arcade game. 
GNU General Public License.